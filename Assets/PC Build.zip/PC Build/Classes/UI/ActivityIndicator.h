#pragma once

void	ShowActivityIndicator(UIView* parent, int style);
void	ShowActivityIndicator(UIView* parent);
void	HideActivityIndicator();
